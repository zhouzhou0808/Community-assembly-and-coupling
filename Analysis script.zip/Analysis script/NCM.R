
rm(list = ls())

#load packages
library(vegan)
library(Hmisc)
library(minpack.lm)
library(grid)
#############################################
#spp<-read.csv('otu_table.csv',head=T,stringsAsFactors=F,row.names=1)
otu_w_E
otu_w_E_6 <- otu_w_E[, -c(1:6)]
otu_w_L
otu_w_L_6 <- otu_w_L[, -c(1:6)]
otu_s_E
otu_s_E_6 <- otu_s_E[, -c(1:6)]
otu_s_L
otu_s_L_6 <- otu_s_L[, -c(1:6)]

spp<-t(otu_w_E_6)

spp<-t(otu_w_L_6)

spp<-t(otu_s_E_6)

spp<-t(otu_s_L_6)

N <- mean(apply(spp, 1, sum))
p.m <- apply(spp, 2, mean)
p.m <- p.m[p.m != 0]
p <- p.m/N
spp.bi <- 1*(spp>0)
freq <- apply(spp.bi, 2, mean)
freq <- freq[freq != 0]
C <- merge(p, freq, by=0)
C <- C[order(C[,2]),]
C <- as.data.frame(C)
C.0 <- C[!(apply(C, 1, function(y) any(y == 0))),]
p <- C.0[,2]
freq <- C.0[,3]
names(p) <- C.0[,1]
names(freq) <- C.0[,1]
d = 1/N

##Fit model parameter m (or Nm) using Non-linear least squares (NLS)
m.fit <- nlsLM(freq ~ pbeta(d, N*m*p, N*m*(1 -p), lower.tail=FALSE),start=list(m=0.1))
m.fit #get the m value
m.ci <- confint(m.fit, 'm', level=0.95)
freq.pred <- pbeta(d, N*coef(m.fit)*p, N*coef(m.fit)*(1 -p), lower.tail=FALSE)
pred.ci <- binconf(freq.pred*nrow(spp), nrow(spp), alpha=0.05, method="wilson", return.df=TRUE)
Rsqr <- 1 - (sum((freq - freq.pred)^2))/(sum((freq - mean(freq))^2))
Rsqr# get the R2 value
coef(m.fit)
#Drawing the figure using grid package:
#p is the mean relative abundance
#freq is occurrence frequency
#freq.pred is predicted occurrence frequency
bacnlsALL <-data.frame(p,freq,freq.pred,pred.ci[,2:3])
inter.col<-rep('gray',nrow(bacnlsALL))
inter.col[bacnlsALL$freq <= bacnlsALL$Lower]<-'#FF9966'#define the color of below points
inter.col[bacnlsALL$freq >= bacnlsALL$Upper]<-'#95D1D7'#define the color of up points


pdf("otu_s_LNCM.pdf", width = 8, height = 6, bg = "transparent")
grid.newpage()
pushViewport(viewport(h=0.6,w=0.5))
pushViewport(dataViewport(xData=range(log10(bacnlsALL$p)), yData=c(0,1.02),extension=c(0.03,0)))
grid.rect()
grid.points(log10(bacnlsALL$p), bacnlsALL$freq,pch=20,gp=gpar(col=inter.col,cex=0.5))
grid.yaxis()
grid.xaxis()
grid.lines(log10(bacnlsALL$p),bacnlsALL$freq.pred,gp=gpar(col='#4DB2F0',lwd=2),default='native')

grid.lines(log10(bacnlsALL$p),bacnlsALL$Lower ,gp=gpar(col='#4DB2F0',lwd=2,lty=2),default='native') 
grid.lines(log10(bacnlsALL$p),bacnlsALL$Upper,gp=gpar(col='#4DB2F0',lwd=2,lty=2),default='native')  
grid.text(y=unit(0,'npc')-unit(2.5,'lines'),label='Mean Relative Abundance (log10)', gp=gpar(fontface=1)) 
grid.text(x=unit(0,'npc')-unit(3,'lines'),label='Occurrence frequency',gp=gpar(fontface=1),rot=90) 

grid.text(label = "Virus (host)", 
          x = unit(0.5, "npc"),   # x=0.5 
          y = unit(1, "npc") + unit(0.5, "lines"),  
          gp = gpar(fontface = 1))  

#add legends
draw.text <- function(just, i, j) {
  grid.text(paste("Rsqr=",round(Rsqr,3),"\n","Nm=",round(coef(m.fit)*N)), x=x[j], y=y[i], just=just)
}
x <- unit(1:4/5, "npc")
y <- unit(1:4/5, "npc")
draw.text(c("centre", "bottom"), 4, 1)

#legend_x <- unit(0.8, "npc")  
#legend_y <- unit(0.9, "npc")  
#legend_spacing <- unit(1.2, "lines")  
# 1：Above prediction
grid.circle(x = 0.05, y = 0.75, r = unit(0.2, "lines"),
            gp = gpar(fill = "#95D1D7", col = "black"))
grid.text("Above prediction", x = 0.05 + 0.05, y = 0.75,
          just = "left", gp = gpar(fontsize = 10))

#  2：Below prediction
grid.circle(x = 0.05, y = 0.75 - 0.1, r = unit(0.2, "lines"),
            gp = gpar(fill = "#FF9966", col = "black"))
grid.text("Below prediction", x = 0.05 + 0.05, y = 0.75 - 0.1,
          just = "left", gp = gpar(fontsize = 10))

dev.off()


table(inter.col)

counts <- c(Above = 14460,
            Below = 2894,
            Neutral = 5318)

colors <- c("#95D1D7", "#FF9966", "gray")


prop <- counts / sum(counts)


labels <- paste0(names(counts), "\n",
                 round(prop * 100, 1), "%")


ord <- order(prop, decreasing = TRUE)
counts <- counts[ord]
labels <- labels[ord]
colors <- colors[ord]

pdf("otu_s_Lneutral_model_pie_beautified.pdf", width = 6, height = 6)

par(mar = c(2, 2, 2, 8))  

pie(counts,
    labels = labels,
    col = colors,
    border = "white",
    lwd = 2,
    main = "Neutral Model Classification",
    cex = 1.1)

legend("topright",
       legend = names(counts),
       fill = colors,
       bty = "n",
       cex = 1)

dev.off()

