#load packages
library(vegan)
library(ape)
library(plspm)

otu_tax_combined <- read.csv("../OTU_Tax.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]

# Extract phylum and sample data
species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))
phylum_df <- species_B[, "Phylum", drop = FALSE]
# 2. Remove the last 8 columns (retain the preceding abundance data)
Gro_raw <- read_excel("../Taxonomy.reads.xlsx", sheet = 2) %>%
  column_to_rownames(var = colnames(.)[1])
otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
# Calculate relative abundance
rotu_no_tax <- as.data.frame(
  apply(otu_no_tax, 2, function(x) x / sum(x))
)
colnames(otu_no_tax)
water_samp <- Gro_raw %>% 
  filter(TYPE == "water") %>% 
  rownames()
otu_w <- otu_no_tax[, water_samp, drop = FALSE]

#Water in the late wintering period
otu_w_L <- otu_w[, grepl("NW", colnames(otu_w))]
otu_w_L<-otu_w_L[rowSums(otu_w_L > 10) >= 2, ]
#Water in the early wintering period
otu_w_E <- otu_w[, grepl("PM", colnames(otu_w))]
otu_w_E<-otu_w_E[rowSums(otu_w_E > 10) >= 2, ]

########################################################
########################################################（PCA1+PCA2）PC_df
#####An example 
otu <- otu_w_L
dist <- vegdist(t(otu), method = "bray")
pcoa <- pcoa(dist, correction = "none", rn = NULL)

PC1 <- pcoa$vectors[, 1]
PC2 <- pcoa$vectors[, 2]

PC_dfs_L <- data.frame(PC1 = PC1, PC2 = PC2)
rownames(PC_df) <- rownames(t(otu))
########################################################env_T_TDS/env_ADE/env_H
env_data <- read_excel("Table.xlsx",sheet="S2-Env-S")
env_data <- as.data.frame(env_data)
rownames(env_data) <- env_data$ID
env_data_L <- env_data %>% filter(PERIOD == "LWP")
env_data_E <- env_data %>% filter(PERIOD == "EWP")
###
env_data_L_LHYZ <- env_data_L[, 3, drop = FALSE]# physicochemical properties of water
env_data_L_LHYZ <- env_data_L_LHYZ[, -c(2)]
env_data_L_YYY<- env_data_L[, 4:5]#nutrient levels
env_data_L_YYY<- env_data_L_YYY[, -1]
env_data_L_ch <- env_data_L[, "Chl.a", drop = FALSE]#chlorophyll a
###
library(corrplot)
cor_mat <- cor(env_data_L_YYY, use = "complete.obs")
corrplot(cor_mat,
         method = "color",  
         type = "upper",      
         addCoef.col = "black",
         number.cex = 0.8, 
         tl.cex = 0.9,    
         sig.level = c(0.05, 0.01),
         pch.cex = 1,
         col = colorRampPalette(c("#8DD3C7", "white", "#FB8072"))(100))


##################################MST#################################
load("../otu_w_Lmst_result.RData")
load("../otu_w_Emst_result.RData")

df <- mst_result$index.pair
tmp <- data.frame(
  sample = c(df$name1, df$name2),
  MST = c(df$MST.ij.bray, df$MST.ij.bray)
)
mat <- aggregate(MST ~ sample, data = tmp, FUN = mean)
#mat
#mean(mat$MST, na.rm = TRUE)
mat <- mat[match(rownames(env_data_L), mat$sample), ]
rownames(mat) <- mat$sample
mat$sample <- NULL
#####################################PLS-PM######################
colnames(env_data_wL_LHYZ) <- paste0("W", colnames(env_data_wL_LHYZ))
colnames(env_data_wL_YYY)  <- paste0("W", colnames(env_data_wL_YYY))
colnames(env_data_wL_ch)   <- paste0("W", colnames(env_data_wL_ch))
rownames(env_data_wL_LHYZ) <- rownames(mat)
rownames(env_data_wL_YYY)  <- rownames(mat)
rownames(env_data_wL_ch)   <- rownames(mat)
df <- cbind(mat,env_data_L_LHYZ,env_data_L_YYY,PC_dfs_L,
            env_data_wL_LHYZ,env_data_wL_YYY,env_data_wL_ch)

df <- as.data.frame(df)
df[] <- lapply(df, function(x) as.numeric(as.character(x)))
dat <- scale(df)
dat_blocks <- list(
F_mean   = "mean",
MST      = "MST",
Env_LHYZ = c("T","TDS","PH"),
Env_YYY  = c("NH₃-N","TN","TP"), 
Chl.a    = "Chl.a",
PCA      = c("PC1","PC2")    
)

 Env_YYY    =  c(0	,0	,0	,0	,0)
Env_LHYZ  =  c(0	,0	,0	,0	,0)
Chl.a          =  c(0	,0	,0	,0	,0)
MST           =  c(1	,1	,1	,0	,0) 
PCA           =  c(1	,1	,1	,1	,0)


dat_path <- rbind(
	          Env_LHYZ
                  Env_YYY , 
                  Chl.a   ,
                  MST,
                  PCA  )
colnames(dat_path) <- rownames(dat_path)
dat_path
dat_modes <- rep("A",5)
dat_modes
dat_pls <- plspm(dat,dat_path,dat_blocks,modes=dat_modes)

dat_pls
summary(dat_pls)
save(dat, dat_path, dat_blocks, dat_modes, dat_pls, file = "w_Eplspm_all_data.RData")
