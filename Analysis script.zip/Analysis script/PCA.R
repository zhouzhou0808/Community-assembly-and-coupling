#load packages
library(vegan)
library(ggplot2)

# 1. Transform dataframe 
otu_s_1<-otu_s[rowSums(otu_s > 10) >= 2, ]
otu_t <- t(otu_s_1)
otu_t <- t(otu_w)
# 2. Grouping
group <- factor(c(rep("PF", 39), rep("ND", 39))) 

# 3. Bray-Curtis & PCoA
dis <- vegdist(otu_t, method = "bray")
pcoa <- cmdscale(dis, k = 2, eig = TRUE)
pcoa_df <- as.data.frame(pcoa$points)
colnames(pcoa_df) <- c("PCoA1", "PCoA2")
pcoa_df$Group <- group

# 4. Extract axis explanatory variance
eig <- pcoa$eig
eig1 <- round(eig[1]/sum(eig)*100, 2)
eig2 <- round(eig[2]/sum(eig)*100, 2)
perma_bac <- adonis2(dis ~ group, permutations = 999)


perma_bac
# 5. PCoA_plot
ggplot(pcoa_df, aes(PCoA1, PCoA2, color = Group)) +
  geom_point(size = 3, alpha = 0.8) +
  stat_ellipse(level = 0.95) +
  
  labs(x = paste0("PCoA1 (", eig1, "%)"),
       y = paste0("PCoA2 (", eig2, "%)")) +
 
  scale_color_manual(values = c("PF" = "#FF9966", "ND" = "#95D1D7"),
                     labels = c("Early winter sediment (PF)", "Late winter sediment (ND)")) +
 
  annotate("text", x = -Inf, y = Inf, 
           label = expression(paste("PERMANOVA: ", R^2 == 0.131, ", P < 0.001")),
           hjust = 0, vjust = 1, size = 3.5) +
  theme_bw() +

  theme(panel.grid = element_blank(),
        legend.position = "bottom")

