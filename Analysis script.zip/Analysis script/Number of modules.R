# load packages
library(ggplot2)
library(dplyr)
library(tidyr)
library(patchwork)

# ========== 1. load data ==========
load("../NWGCNA_net.RData")
L_S<-table(net$colors)
load("./PFWGCNA_net.RData")
E_S<-table(net$colors)
load("../../../2026小论文/wgcna/WGCNA_net.RData")
L_W<-table(net$colors)
load("../../../2026小论文/wgcna/pre/WGCNA_net.RData")
E_W<-table(net$colors)


myColors <- c(
  "#EDD7D7", "#8DD3C7", "#BEBADA", "#FDB462", "#FB8072",
  "#FCCDE5", "#F6D8AE", "#CCEBC5", "#FFED6F", "#80B1D3",
  "#B3DE69", "#A791C0", "#FFFFB3" 
)

# ========== 2. Transform dataframe ==========
df_LS <- as.data.frame(L_S) %>% setNames(c("Module","Count"))
df_ES <- as.data.frame(E_S) %>% setNames(c("Module","Count"))
df_LW <- as.data.frame(L_W) %>% setNames(c("Module","Count"))
df_EW <- as.data.frame(E_W) %>% setNames(c("Module","Count"))

# ========== 3 Visualize data ==========

theme_clean <- theme_bw() +
  theme(
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(), 
    legend.position = "none"
  )

p1 <- ggplot(df_LS, aes(x = Module, y = Count, fill = Module)) +
  geom_col() +
  scale_fill_manual(values = myColors[1:nrow(df_LS)]) +
  labs(title = "L_S", x = "Module", y = "Number") +
  theme_clean

p2 <- ggplot(df_ES, aes(x = Module, y = Count, fill = Module)) +
  geom_col() +
  scale_fill_manual(values = myColors[1:nrow(df_ES)]) +
  labs(title = "E_S", x = "Module", y = "Number") +
  theme_clean

p3 <- ggplot(df_LW, aes(x = Module, y = Count, fill = Module)) +
  geom_col() +
  scale_fill_manual(values = myColors[1:nrow(df_LW)]) +
  labs(title = "L_W", x = "Module", y = "Number") +
  theme_clean

p4 <- ggplot(df_EW, aes(x = Module, y = Count, fill = Module)) +
  geom_col() +
  scale_fill_manual(values = myColors[1:nrow(df_EW)]) +
  labs(title = "E_W", x = "Module", y = "Number") +
  theme_clean


p1 + p2 + p3 + p4 + plot_layout(ncol = 2, nrow = 2)
p4 + p3 + p2 + p1 + plot_layout(ncol = 2, nrow = 2)
