library(tidyr)
library(dplyr)
library(readxl)
library(ggplot2)
library(ggsci)
library(patchwork)
library(writexl)
library(tibble)
library(readxl)
library(dplyr)

###########################################Analysis of species composition and abundance############################

otu_tax_combined <- read.csv("../OTU_Tax.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]

# Extract phylum and sample data
species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))
phylum_df <- species_B[, "Phylum", drop = FALSE]
# 2. Remove the last 8 columns (retain the preceding abundance data)
Gro_raw <- read_excel("../Taxonomy.reads.xlsx", sheet = 2) %>%
  column_to_rownames(var = colnames(.)[1])
otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
# Calculate relative abundance
rotu_no_tax <- as.data.frame(
  apply(otu_no_tax, 2, function(x) x / sum(x))
)
colnames(otu_no_tax)
water_samp <- Gro_raw %>%
  filter(TYPE == "water") %>%
  rownames()
otu_w <- otu_no_tax[, water_samp, drop = FALSE]

water_samp <- Gro_raw %>%
  filter(TYPE == "sediment") %>%
  rownames()
otu_s <- otu_no_tax[, water_samp, drop = FALSE]

########## Calculate differences in physicochemical properties between pre- and post-overwintering periods
Env_w <- read_excel("Table.xlsx", sheet = "S1-Env-W")
# Convert first column to row names
Env_w <- Env_w %>% column_to_rownames(var = names(.)[1])
Env_s <- read_excel("Table.xlsx", sheet = "S2-Env-S")
Env_s <- Env_s %>% column_to_rownames(var = names(.)[1])

test_cols <- 2:12
# Batch calculation: mean ± SD + Wilcoxon test P-value + significance
res_list <- lapply(test_cols, function(i){
  col_name <- colnames(Env_w)[i]
  vec <- Env_w[[i]]
  # Calculate mean and SD by group
  m <- tapply(vec, Env_w$PERIOD, mean, na.rm = TRUE)
  s <- tapply(vec, Env_w$PERIOD, sd, na.rm = TRUE)
  # Format as mean ± SD, keep 3 decimal places
  group1 <- paste0(round(m[1], 3), " ± ", round(s[1], 3))
  group2 <- paste0(round(m[2], 3), " ± ", round(s[2], 3))
  # Wilcoxon rank-sum test between two groups
  wt <- wilcox.test(vec ~ Env_w$PERIOD)

  data.frame(
    Variable = col_name,
    Mean_SD_Group1 = group1,
    Mean_SD_Group2 = group2,
    p_value = wt$p.value,
    stringsAsFactors = FALSE
  )

})
unique(Env_w$PERIOD)
# Combine result table
diff_result <- bind_rows(res_list)
# Process P-value: fix floating point error, format, add significance markers
diff_result <- diff_result %>%
  mutate(
    # Mark very small P-values as < 2.2e-16, keep 8 decimal places for others
    p_show = ifelse(abs(p_value) < 2.2e-16, "< 2.2e-16", round(p_value, 8)),
    # Significance
    Significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01  ~ "**",
      p_value < 0.05  ~ "*",
      TRUE            ~ "ns"
    )
  ) %>%
  # Adjust column order, hide raw p_value, output final table
  select(Variable, Mean_SD_Group1, Mean_SD_Group2, p_show, Significance)
# View results
print(diff_result, row.names = FALSE)
write.csv(
  diff_result,
  file = "w.csv",       # Custom filename
  row.names = FALSE,     # Disable auto-generated row numbers (avoid redundancy)
  fileEncoding = "UTF-8" # Universal encoding, compatible with most systems
)
test_cols <- 2:4
# Batch calculation: mean ± SD + Wilcoxon test P-value + significance
res_list <- lapply(test_cols, function(i){
  col_name <- colnames(Env_s)[i]
  vec <- Env_s[[i]]
  # Calculate mean and SD by group
  m <- tapply(vec, Env_s$PERIOD, mean, na.rm = TRUE)
  s <- tapply(vec, Env_s$PERIOD, sd, na.rm = TRUE)
  # Format as mean ± SD, keep 3 decimal places
  group1 <- paste0(round(m[1], 3), " ± ", round(s[1], 3))
  group2 <- paste0(round(m[2], 3), " ± ", round(s[2], 3))
  # Wilcoxon rank-sum test between two groups
  wt <- wilcox.test(vec ~ Env_s$PERIOD)

  data.frame(
    Variable = col_name,
    Mean_SD_Group1 = group1,
    Mean_SD_Group2 = group2,
    p_value = wt$p.value,
    stringsAsFactors = FALSE
  )
})
# Combine result table
diff_result <- bind_rows(res_list)
# Process P-value: fix floating point error, format, add significance markers
diff_result <- diff_result %>%
  mutate(
    # Mark very small P-values as < 2.2e-16, keep 8 decimal places for others
    p_show = ifelse(abs(p_value) < 2.2e-16, "< 2.2e-16", round(p_value, 8)),
    # Significance
    Significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01  ~ "**",
      p_value < 0.05  ~ "*",
      TRUE            ~ "ns"
    )
  ) %>%
  # Adjust column order, hide raw p_value, output final table
  select(Variable, Mean_SD_Group1, Mean_SD_Group2, p_show, Significance)
# View results
print(diff_result, row.names = FALSE)
write.csv(
  diff_result,
  file = "s.csv",       # Custom filename
  row.names = FALSE,     # Disable auto-generated row numbers (avoid redundancy)
  fileEncoding = "UTF-8" # Universal encoding, compatible with most systems
)
## Extract required samples
samp <- Gro_raw %>%
  filter(TYPE == "water" | TYPE == "sediment") %>%
  rownames()
otu <- otu_no_tax[, samp, drop = FALSE]
otu <- otu[rowSums(otu > 0) > 0, , drop = FALSE]
otu[] <- lapply(otu, function(x) gsub("\\s", "", x))
phylum_df[] <- lapply(phylum_df, function(x) gsub("\\s", "", x))
otu_tax <- otu %>%
  rownames_to_column("ID") %>%    # Convert row names to column
  inner_join(
    phylum_df %>% rownames_to_column("ID"),
    by = "ID"
  ) %>%
  column_to_rownames("ID")        # Restore row names
colnames(otu_tax)
str(otu_tax)
otu_tax[,1:156] <- lapply(otu_tax[,1:156], as.numeric)
# 2. Sum by phylum (total abundance of each phylum across all samples)
otu_tax_sum <- otu_tax %>%
  group_by(Phylum) %>%
  summarise(across(everything(), sum), .groups = "drop")

otu_tax_sum <- otu_tax_sum %>%
  mutate(total = rowSums(across(2:ncol(.)))) %>%
  arrange(desc(total)) %>%
  select(-total)

otu_tax_sum
ND_top7 <- otu_tax_sum %>%
  mutate(mean_abundance = rowMeans(select(., starts_with("ND")))) %>%
  arrange(desc(mean_abundance)) %>%
  slice(1:7) %>%
  select(Phylum, mean_abundance)

# NW group
NW_top7 <- otu_tax_sum %>%
  mutate(mean_abundance = rowMeans(select(., starts_with("NW")))) %>%
  arrange(desc(mean_abundance)) %>%
  slice(1:7) %>%
  select(Phylum, mean_abundance)

# PM group
PM_top7 <- otu_tax_sum %>%
  mutate(mean_abundance = rowMeans(select(., starts_with("PM")))) %>%
  arrange(desc(mean_abundance)) %>%
  slice(1:7) %>%
  select(Phylum, mean_abundance)

# PF group
PF_top7 <- otu_tax_sum %>%
  mutate(mean_abundance = rowMeans(select(., starts_with("PF")))) %>%
  arrange(desc(mean_abundance)) %>%
  slice(1:7) %>%
  select(Phylum, mean_abundance)
ND_top7
NW_top7
PM_top7
PF_top7
top_phylum <- unique(c(
  ND_top7 %>%
    filter(Phylum != "p__norank") %>%
    pull(Phylum),

  NW_top7 %>%
    filter(Phylum != "p__norank") %>%
    pull(Phylum),

  PM_top7 %>%
    filter(Phylum != "p__norank") %>%
    pull(Phylum),

  PF_top7 %>%
    filter(Phylum != "p__norank") %>%
    pull(Phylum)
))
top_phylum
otu_plot <- otu_tax_sum

otu_plot$Phylum <- ifelse(
  otu_plot$Phylum %in% top_phylum,
  otu_plot$Phylum,
  "Others"
)

## Merge Others
otu_plot <- otu_plot %>%
  group_by(Phylum) %>%
  summarise(across(where(is.numeric), sum), .groups = "drop")

## Plotting function
plot_group <- function(prefix){

  ## Extract corresponding group
  dat <- otu_plot %>%
    select(Phylum, starts_with(prefix))

  sample_order <- colnames(dat)[-1]

  ## Convert to long format
  dat_long <- dat %>%
    pivot_longer(
      cols = -Phylum,
      names_to = "sample",
      values_to = "abundance"
    ) %>%
    group_by(sample) %>%
    mutate(abundance = abundance / sum(abundance)) %>%
    ungroup()

  ## Preserve sample order
  dat_long$sample <- factor(
    dat_long$sample,
    levels = sample_order
  )

  ## Phylum ordering (Others last)
  phylum_order <- dat_long %>%
    group_by(Phylum) %>%
    summarise(mean = mean(abundance)) %>%
    arrange(desc(mean)) %>%
    pull(Phylum)

  phylum_order <- c(setdiff(phylum_order, "Others"), "Others")

  dat_long$Phylum <- factor(
    dat_long$Phylum,
    levels = phylum_order
  )

  ## Plot
  ggplot(dat_long,
         aes(x = sample,
             y = abundance,
             fill = Phylum)) +

    geom_bar(
      stat = "identity",
      width = 1
    ) +

    annotate(
      "rect",
      xmin = 0.5,
      xmax = length(sample_order) + 0.5,
      ymin = 0,
      ymax = 1,
      colour = "black",
      fill = NA,
      linewidth = 0.5
    ) +

    scale_fill_manual(
      values = c(
        "p__Bacteroidota"="#FB8072",
        "p__Pseudomonadota"="#8DD3C7",
        "p__Actinomycetota"="#FDB462",
        "p__Myxococcota"="#CA81A9",
        "p__Acidobacteriota"="#BC80DB",
        "p__Bacillota"="#C7E1A6",
        "p__Cyanobacteriota"="#487DB2",
        "p__Verrucomicrobiota"="#CCEBC5",
        "p__Planctomycetota"="#EEEDBC",
        "Others"="#CCCACB"
      )
    ) +

    scale_x_discrete(expand = c(0,0)) +
    scale_y_continuous(expand = c(0,0), limits = c(0,1)) +

    labs(
      x = "",
      y = prefix,
      fill = "Phylum"
    ) +

    theme_minimal() +

    theme(

      axis.ticks = element_blank(),

      panel.grid = element_blank(),

      axis.text.x = element_blank(),

      axis.text.y = element_blank(),

      axis.title.x = element_blank(),

      axis.title.y = element_text(
        size = 14,
        face = "bold",
        margin = margin(r = 2)
      ),

      panel.border = element_blank(),

      ## Legend at bottom
      legend.position = "bottom",

      ## Horizontal arrangement
      legend.direction = "horizontal",

      ## Legend title
      legend.title = element_text(
        size = 12,
        face = "bold"
      ),

      ## Legend text
      legend.text = element_text(
        size = 10
      ),

      ## Legend key size
      legend.key.size = unit(0.4, "cm"),

      ## Legend spacing
      legend.spacing.x = unit(0.2, "cm"),

      ## Legend background
      legend.background = element_blank(),

      plot.margin = margin(2,2,2,2)
    ) +
    guides(
      fill = guide_legend(
        nrow = 2,
        byrow = TRUE
      )
    )
}

## Four plots
p1 <- plot_group("ND")
p2 <- plot_group("NW")
p3 <- plot_group("PM")
p4 <- plot_group("PF")
p1
p2
p3
p4
# ====================== Calculate phylum percentages ======================
# Define batch calculation function, output relative abundance (%)
calc_phylum_percent <- function(prefix){
  dat <- otu_plot %>%
    select(Phylum, starts_with(prefix))

  # Convert to long format + calculate percentage
  res <- dat %>%
    pivot_longer(cols = -Phylum, names_to = "Sample", values_to = "Abundance") %>%
    group_by(Sample) %>%
    mutate(Percent = round(Abundance / sum(Abundance) * 100, 2)) %>%
    ungroup() %>%
    select(Sample, Phylum, Percent) %>%
    pivot_wider(names_from = Phylum, values_from = Percent)

  return(res)
}

# Calculate percentage tables for four groups
percent_ND  <- calc_phylum_percent("ND")
percent_NW  <- calc_phylum_percent("NW")
percent_PM  <- calc_phylum_percent("PM")
percent_PF  <- calc_phylum_percent("PF")

# View results
cat("========== ND Group Phylum Relative Abundance (%) ==========\n")
print(percent_ND, row.names = FALSE)

cat("\n========== NW Group Phylum Relative Abundance (%) ==========\n")
print(percent_NW, row.names = FALSE)

cat("\n========== PM Group Phylum Relative Abundance (%) ==========\n")
print(percent_PM, row.names = FALSE)

cat("\n========== PF Group Phylum Relative Abundance (%) ==========\n")
print(percent_PF, row.names = FALSE)

all_mean_table <- bind_rows(
  # ND
  percent_ND %>%
    pivot_longer(cols = -Sample, names_to = "Phylum", values_to = "Percent") %>%
    group_by(Phylum) %>%
    summarise(Mean_Pct = round(mean(Percent), 2), Group = "ND", .groups = "drop"),

  # NW
  percent_NW %>%
    pivot_longer(cols = -Sample, names_to = "Phylum", values_to = "Percent") %>%
    group_by(Phylum) %>%
    summarise(Mean_Pct = round(mean(Percent), 2), Group = "NW", .groups = "drop"),

  # PM
  percent_PM %>%
    pivot_longer(cols = -Sample, names_to = "Phylum", values_to = "Percent") %>%
    group_by(Phylum) %>%
    summarise(Mean_Pct = round(mean(Percent), 2), Group = "PM", .groups = "drop"),

  # PF
  percent_PF %>%
    pivot_longer(cols = -Sample, names_to = "Phylum", values_to = "Percent") %>%
    group_by(Phylum) %>%
    summarise(Mean_Pct = round(mean(Percent), 2), Group = "PF", .groups = "drop")
)

# View all rows (no truncation)
print(all_mean_table, n = Inf)

# Export CSV for later use
write.csv(all_mean_table, "phylum_mean_abundance.csv", row.names = FALSE, fileEncoding = "UTF-8")
#################################Chao1 and Shannon##########################################
rm(list = ls())
library(vegan) # Alpha diversity calculation using the vegan package
library(ggpubr)
library(patchwork)
## Content partially removed #################
####################################
#comun = read.csv("species_abundance_table.csv",header=T,row.names=1)
#comun <- final_data %>%
select(-Phylum)
# Force conversion to pure numeric matrix
otu_num <- as.data.frame(apply(otu, 2, as.numeric))

# 2. Convert to pure numeric matrix
otu_mat <- as.matrix(otu_num)

# 3. Dual filtering: at least 2 samples with abundance, row total abundance >= 10
keep <- rowSums(otu_mat > 0) >= 2 & rowSums(otu_mat) >= 10

# 4. Get filtered results
comun_mat <- otu_mat[keep, , drop = FALSE]

# Convert back to data frame as needed
comun <- as.data.frame(comun_mat)
#comun <- comun[apply(comun, 1, max, na.rm = TRUE) >= 1000, ]
colnames(comun)
otu <- as.data.frame(comun)
#rownames(otu) <- otu[, 1]  # Assign first column as row names
#otu <- otu[, -1]
otu <- t(otu) # Transpose otu table

alpha_index <- function(x, base = exp(1)) {    # Convenience function to calculate all alpha indices at once
  observed_species <- estimateR(x)[1,]#observed_species
  richness <- rowSums(x > 0)	# Richness index
  chao1 <- estimateR(x)[2, ]	# Chao1 index
  ace <- estimateR(x)[4, ]	# ACE index
  shannon <- diversity(x, index = 'shannon', base = base)	# Shannon index
  simpson <- diversity(x, index = 'simpson')	# Gini-Simpson index
  pielou <- diversity(x, index = 'shannon', base = base) / log(estimateR(x)[1, ], base)	# Pielou evenness
  goods_covers <- 1 - rowSums(x == 1) / rowSums(x)	# Goods coverage
  result <- data.frame(observed_species, richness, chao1, ace, shannon, simpson, pielou, goods_covers)
}
alpha <- alpha_index(otu)
Gro_raw$group <- paste(Gro_raw$TYPE, Gro_raw$PERIOD, sep = "_")
alpha$group <- Gro_raw[rownames(alpha), "group"]
write.csv(alpha, "alpha_index.csv",row.names = T ) # Write all alpha indices to file
colnames(alpha)
# Feces
alpha_F <- alpha[grep("faeces", alpha$group), ]
# Feathers
alpha_H <- alpha[grep("feather", alpha$group), ]
# Water
alpha_W <- alpha[grep("water", alpha$group), ]
# Sediment
alpha_D <- alpha[grep("sediment", alpha$group), ]
wilcox.test(chao1 ~ group, data = alpha_D)
# 2. Shannon index
wilcox.test(shannon ~ group, data = alpha_D)
# 3. Simpson index
wilcox.test(simpson ~ PERIOD, data = alpha_D)
alpha_D %>%
  group_by(group) %>%
  summarise(
    n_samples = n(),
    chao1_mean = mean(chao1, na.rm = T),
    shannon_mean = mean(shannon, na.rm = T),
    simpson_mean = mean(simpson, na.rm = T)
  )
#########


# Extract chao1 column, split into two groups
nw <- alpha_W[grepl("^NW", rownames(alpha_W)), "chao1"]
pm <- alpha_W[grepl("^PM", rownames(alpha_W)), "chao1"]

# Take mean per 3 values, yielding 13 values
mean_fun <- function(x) colMeans(matrix(x, nrow = 3))
df <- tibble(
  x = 1:13,
  NW = mean_fun(nw),
  PM = mean_fun(pm)
) %>% pivot_longer(-x, names_to = "Group", values_to = "chao1")

# Plot
ggplot(df, aes(x, chao1, color = Group, group = Group)) +
  geom_line(linewidth = 1) +
  geom_point(shape = 19, size = 4) +
  scale_color_manual(values = c("NW" = "#8DD3C7", "PM" = "#FB8072")) +
  scale_x_continuous(breaks = 1:13, labels = paste0("P", 1:13)) +
  labs(x = "", y = "chao1") +
  theme_bw() +
  theme(panel.grid = element_blank())

nw <- alpha_W[grepl("^NW", rownames(alpha_W)), "shannon"]
pm <- alpha_W[grepl("^PM", rownames(alpha_W)), "shannon"]

# Take mean per 3 values, yielding 13 values
mean_fun <- function(x) colMeans(matrix(x, nrow = 3))
df <- tibble(
  x = 1:13,
  NW = mean_fun(nw),
  PM = mean_fun(pm)
) %>% pivot_longer(-x, names_to = "Group", values_to = "shannon")

# Plot
ggplot(df, aes(x, shannon, color = Group, group = Group)) +
  geom_line(linewidth = 1) +
  geom_point(shape = 19, size = 4) +
  scale_color_manual(values = c("NW" = "#8DD3C7", "PM" = "#FB8072")) +
  scale_x_continuous(breaks = 1:13, labels = paste0("P", 1:13)) +
  labs(x = "", y = "shannon") +
  theme_bw() +
  theme(panel.grid = element_blank())

#######################################

# Extract chao1 column, split into two groups
nw <- alpha_D[grepl("^ND", rownames(alpha_D)), "chao1"]
pm <- alpha_D[grepl("^PF", rownames(alpha_D)), "chao1"]

# Take mean per 3 values, yielding 13 values
mean_fun <- function(x) colMeans(matrix(x, nrow = 3))
df <- tibble(
  x = 1:13,
  NW = mean_fun(nw),
  PM = mean_fun(pm)
) %>% pivot_longer(-x, names_to = "Group", values_to = "chao1")

# Plot
ggplot(df, aes(x, chao1, color = Group, group = Group)) +
  geom_line(linewidth = 1) +
  geom_point(shape = 19, size = 4) +
  scale_color_manual(values = c("NW" = "#8DD3C7", "PM" = "#FB8072")) +
  scale_x_continuous(breaks = 1:13, labels = paste0("P", 1:13)) +
  labs(x = "", y = "chao1") +
  theme_bw() +
  theme(panel.grid = element_blank())



# Extract chao1 column, split into two groups
nw <- alpha_D[grepl("^ND", rownames(alpha_D)), "shannon"]
pm <- alpha_D[grepl("^PF", rownames(alpha_D)), "shannon"]

# Take mean per 3 values, yielding 13 values
mean_fun <- function(x) colMeans(matrix(x, nrow = 3))
df <- tibble(
  x = 1:13,
  NW = mean_fun(nw),
  PM = mean_fun(pm)
) %>% pivot_longer(-x, names_to = "Group", values_to = "shannon")

# Plot
ggplot(df, aes(x, shannon, color = Group, group = Group)) +
  geom_line(linewidth = 1) +
  geom_point(shape = 19, size = 4) +
  scale_color_manual(values = c("NW" = "#8DD3C7", "PM" = "#FB8072")) +
  scale_x_continuous(breaks = 1:13, labels = paste0("P", 1:13)) +
  labs(x = "", y = "shannon") +
  theme_bw() +
  theme(panel.grid = element_blank())

ggplot(df, aes(x, shannon, color = Group, group = Group)) +
  geom_line(linewidth = 1) +
  geom_point(shape = 19, size = 4) +
  geom_smooth(method = "loess", se = TRUE, linewidth = 0.8, alpha = 0.2) +
  # Group annotation: correlation coefficient R + P-value
  stat_cor(label.x = 2, label.y.npc = c(0.95, 0.85), size = 3.5) +
  scale_color_manual(values = c("NW" = "#8DD3C7", "PM" = "#FB8072")) +
  scale_x_continuous(breaks = 1:13, labels = paste0("P", 1:13)) +
  labs(x = "", y = "shannon") +
  theme_bw() +
  theme(panel.grid = element_blank())
#######WGCNA - Water and Sediment Network Correlation###########################################################
library(Hmisc)
library(pheatmap)
##### EWP ###################
PF <- read.csv("./WGCNA/PFMEs.csv", row.names = 1, check.names = FALSE) # Sediment
common_sample <- intersect(colnames(otu_s), rownames(PF))
PF <- PF[common_sample, , drop = FALSE]
del_samples <- c("PF1-1","PF1-2","PF1-3","PF2-1","PF2-2","PF2-3")
PF <- PF[!rownames(PF) %in% del_samples, , drop = FALSE]

NM <- read.csv("../../2026 Paper/wgcna/pre/MEs.csv", row.names = 1, check.names = FALSE) # Water
common_sample <- intersect(colnames(otu_w), rownames(NM))
NM <- NM[common_sample, , drop = FALSE]
del_samples <- c("NW6-1","NW6-2","NW6-3")
NM <- NM[!rownames(NM) %in% del_samples, , drop = FALSE]
##### LWP ###################
PF <- read.csv("./NMEs.csv", row.names = 1, check.names = FALSE) # Sediment
common_sample <- intersect(colnames(otu_s), rownames(PF))
PF <- PF[common_sample, , drop = FALSE]
del_samples <- c("ND1-1","ND1-2","ND1-3","ND2-1","ND2-2","ND2-3")
PF <- PF[!rownames(PF) %in% del_samples, , drop = FALSE]

NM <- read.csv("../../2026 Paper/wgcna/MEs.csv", row.names = 1, check.names = FALSE) # Water
common_sample <- intersect(colnames(otu_w), rownames(NM))
NM <- NM[common_sample, , drop = FALSE]
del_samples <- c("NW6-1","NW6-2","NW6-3")
NM <- NM[!rownames(NM) %in% del_samples, , drop = FALSE]
##############################################################################


# Correlation coefficient
cor_mat <- matrix(NA, ncol(PF), ncol(NM))
p_mat <- matrix(NA, ncol(PF), ncol(NM))

for(i in 1:ncol(PF)){
  for(j in 1:ncol(NM)){
    tmp <- rcorr(PF[,i], NM[,j], type = "pearson")
    cor_mat[i,j] <- tmp$r[1,2]
    p_mat[i,j] <- tmp$P[1,2]
  }
}

rownames(cor_mat) <- colnames(PF)
colnames(cor_mat) <- colnames(NM)

# ===================== Sort by ME number =====================
# Extract row and column names, sort numerically ascending (fixes ME10 appearing before ME2)
row_name <- rownames(cor_mat)
row_num  <- as.integer(gsub("ME", "", row_name))
row_idx  <- order(row_num)

col_name <- colnames(cor_mat)
col_num  <- as.integer(gsub("ME", "", col_name))
col_idx  <- order(col_num)

# Reorder matrix and p-value matrix
cor_mat <- cor_mat[row_idx, col_idx]
p_mat   <- p_mat[row_idx, col_idx]
# ================================================================

# Significance labels (must regenerate label after matrix reordering)
label <- ifelse(
  p_mat < 0.001,
  paste0(sprintf("%.2f", cor_mat), "***"),
  ifelse(
    p_mat < 0.01,
    paste0(sprintf("%.2f", cor_mat), "**"),
    ifelse(
      p_mat < 0.05,
      paste0(sprintf("%.2f", cor_mat), "*"),
      sprintf("%.2f", cor_mat)
    )
  )
)

# Plot: disable clustering, fixed order
pheatmap(
  cor_mat,
  color = colorRampPalette(c("#8DD3C7","white","#FB8072"))(100),
  display_numbers = label,
  border_color = NA,
  cluster_rows = FALSE,   # Disable row clustering
  cluster_cols = FALSE    # Disable column clustering
)

#################################Environmental + Geographic distance decay model################################
# Load required packages
library(ggplot2)
library(vegan)
library(geosphere)

## Calculate distance
# Calculate Bray-Curtis distance between samples based on species abundance data
#abund <- df[ ,15:ncol(df)] ## Input species x sample abundance table
otu_tax_combined <- read.csv("../OTU_Tax_Merged_Table.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]
# Prepare data for subsequent plotting
# Extract phylum and sample data
species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))
phylum_df <- species_B[, "Phylum", drop = FALSE]
# 2. Remove last 8 columns (retain the preceding abundance data)
otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
df <- read_excel("Table.xlsx",sheet = 'S2-Env-S')
df <- as.data.frame(df)
rownames(df) <- df[,1]
df <- df[,-1]
# Filter rows whose names contain EW
df_EW <- df[grepl("PF", rownames(df)), , drop = FALSE]

# Filter rows whose names contain LW
df_LW <- df[grepl("ND", rownames(df)), , drop = FALSE]
abund <- otu_no_tax
abund <- t(abund)
abund <-  abund[rownames(df_EW),]
dist.abund <- vegdist(abund, method = 'bray') # Bray-Curtis dissimilarity
#dist.abund <- 1-vegdist(abund, method = 'bray') # Bray-Curtis similarity
# vegan package vegdist() computes Bray-Curtis dissimilarity matrix of species composition between communities
# Bray-Curtis similarity can be obtained as 1 - Bray-Curtis dissimilarity
# Select a subset of environmental variables, compute Euclidean distance of environmental factors between samples
env <- df_EW[ ,2:4] # @############################################# Select all environmental factors here
scale.env <- scale(env, center = TRUE, scale = TRUE) # Standardize data to eliminate scale differences
dist.env <- dist(scale.env, method = 'euclidean') # Compute environmental factor distance
# Compute actual geographic distance between samples based on longitude and latitude
geo <- data.frame(df_EW$LO, df_EW$LA) # Extract longitude and latitude
d.geo <- distm(geo, fun = distHaversine)    # Compute geographic distance
dist.geo <- as.dist(d.geo)
## Perform Mantel tests, see ?mantel for details
# Correlation between species and environment, using Spearman correlation, 9999 permutations for significance testing
abund_env <- mantel(dist.abund, dist.env, method = 'spearman', permutations = 9999, na.rm = TRUE)
abund_env
# Correlation between species abundance and geographic distance, using Spearman correlation, 9999 permutations for significance testing
abund_geo <- mantel(dist.abund, dist.geo, method = 'spearman', permutations = 9999, na.rm = TRUE)
abund_geo
# Convert distance measures into data frames and align them one-to-one
aa <- as.vector(dist.abund)
bb <- as.vector(dist.env )
cc <-  as.vector(dist.geo)
mat <- data.frame(aa,bb,cc)
# Visualization ---------------------------------------------------------------
### Microorganisms vs Environment
# Add Mantel test results from Step 2
abund_env
Mantel_r <- paste("R=",0.182)
P <- paste("P<",0.05)
mm <- ggplot(mat, aes(y = aa, x = bb)) +
  geom_point(size = 4, alpha = 0.75, colour = "black",shape = 21, aes(fill = bb)) +
  geom_smooth(method = "lm", colour = "black", alpha = 0.2) +
  labs(x = "Environmental distance (C)", y = "Bray-Curtis Dissimilarity", fill = "Environmental gradient") +
  theme( axis.text.x = element_text(face = "bold",colour = "black", size = 12),
         axis.text.y = element_text(face = "bold", size = 11, colour = "black"),
         axis.title= element_text(face = "bold", size = 14, colour = "black"),
         panel.background = element_blank(),
         panel.border = element_rect(fill = NA, colour = "black"),
         legend.position = "top",
         legend.text = element_text(size = 10, face = "bold"),
         legend.title = element_text(size = 11, face = "bold")) +
  scale_fill_continuous(high = "#63bfb8", low = "#52b216")+
  annotate('text', label = Mantel_r, x = 1.5, y = 1.0, size = 5, colour = 'black')+
  annotate('text', label = P, x = 1.5, y = 0.9, size = 5, colour = 'black') +
  ylim(0, 0.8)
mm
## Geographic vs Microorganisms
abund_geo
Mantel_r1 <- paste("R=",0.265)
P1 <- paste("P<",0.001)
gg<- ggplot(mat, aes(y = aa, x = cc)) +
  geom_point(size = 4, alpha = 0.75, colour = "black",shape = 21, aes(fill = cc/1000)) +
  geom_smooth(method = "lm", colour = "black", alpha = 0.2) +
  labs(x = "Geographic distance", y = "Bray-Curtis Dissimilarity", fill = "Geographic gradient") +
  theme( axis.text.x = element_text(face = "bold",colour = "black", size = 12),
         axis.text.y = element_text(face = "bold", size = 11, colour = "black"),
         axis.title= element_text(face = "bold", size = 14, colour = "black"),
         panel.background = element_blank(),
         panel.border = element_rect(fill = NA, colour = "black"),
         legend.position = "top",
         legend.text = element_text(size = 10, face = "bold"),
         legend.title = element_text(size = 11, face = "bold")) +
  scale_fill_continuous(low = "orange3", high = "#FF732324")+
  annotate('text', label = Mantel_r1, x = 5000, y = 0.66, size = 5, colour = 'black')+
  annotate('text', label = P1, x = 5000, y = 0.6, size =5, colour = 'black') +
  ylim(0, 0.7)
gg


# Filter rows whose names contain LW
df_LW <- df[grepl("ND", rownames(df)), , drop = FALSE]
abund <- otu_no_tax
abund <- t(abund)
abund <-  abund[rownames(df_LW),]
dist.abund <- vegdist(abund, method = 'bray') # Bray-Curtis dissimilarity
#dist.abund <- 1-vegdist(abund, method = 'bray') # Bray-Curtis similarity
# vegan package vegdist() computes Bray-Curtis dissimilarity matrix of species composition between communities
# Bray-Curtis similarity can be obtained as 1 - Bray-Curtis dissimilarity
# Select a subset of environmental variables, compute Euclidean distance of environmental factors between samples
env <- df_LW[ ,2:4] # Select all environmental factors here
scale.env <- scale(env, center = TRUE, scale = TRUE) # Standardize data to eliminate scale differences
dist.env <- dist(scale.env, method = 'euclidean') # Compute environmental factor distance
# Compute actual geographic distance between samples based on longitude and latitude
geo <- data.frame(df_LW$LO, df_LW$LA) # Extract longitude and latitude
d.geo <- distm(geo, fun = distHaversine)    # Compute geographic distance
dist.geo <- as.dist(d.geo)
## Perform Mantel tests, see ?mantel for details
# Correlation between species and environment, using Spearman correlation, 9999 permutations for significance testing
abund_env <- mantel(dist.abund, dist.env, method = 'spearman', permutations = 9999, na.rm = TRUE)
abund_env
# Correlation between species abundance and geographic distance, using Spearman correlation, 9999 permutations for significance testing
abund_geo <- mantel(dist.abund, dist.geo, method = 'spearman', permutations = 9999, na.rm = TRUE)
abund_geo
# Convert distance measures into data frames and align them one-to-one
aa <- as.vector(dist.abund)
bb <- as.vector(dist.env )
cc <-  as.vector(dist.geo)
mat <- data.frame(aa,bb,cc)
# Visualization ---------------------------------------------------------------
### Microorganisms vs Environment
# Add Mantel test results from Step 2
abund_env
Mantel_r <- paste("R=",0.211)
P <- paste("P<",0.05)
mm <- ggplot(mat, aes(y = aa, x = bb)) +
  geom_point(size = 4, alpha = 0.75, colour = "black",shape = 21, aes(fill = bb)) +
  geom_smooth(method = "lm", colour = "black", alpha = 0.2) +
  labs(x = "Environmental distance (C)", y = "Bray-Curtis Dissimilarity", fill = "Environmental gradient") +
  theme( axis.text.x = element_text(face = "bold",colour = "black", size = 12),
         axis.text.y = element_text(face = "bold", size = 11, colour = "black"),
         axis.title= element_text(face = "bold", size = 14, colour = "black"),
         panel.background = element_blank(),
         panel.border = element_rect(fill = NA, colour = "black"),
         legend.position = "top",
         legend.text = element_text(size = 10, face = "bold"),
         legend.title = element_text(size = 11, face = "bold")) +
  scale_fill_continuous(high = "#63bfb8", low = "#52b216")+
  annotate('text', label = Mantel_r, x = 1.5, y = 1.0, size = 5, colour = 'black')+
  annotate('text', label = P, x = 1.5, y = 0.9, size = 5, colour = 'black') +
  ylim(0, 0.8)
mm
## Geographic vs Microorganisms
abund_geo
Mantel_r1 <- paste("R=",0.274)
P1 <- paste("P<",0.001)
gg<- ggplot(mat, aes(y = aa, x = cc)) +
  geom_point(size = 4, alpha = 0.75, colour = "black",shape = 21, aes(fill = cc/1000)) +
  geom_smooth(method = "lm", colour = "black", alpha = 0.2) +
  labs(x = "Geographic distance", y = "Bray-Curtis Dissimilarity", fill = "Geographic gradient") +
  theme( axis.text.x = element_text(face = "bold",colour = "black", size = 12),
         axis.text.y = element_text(face = "bold", size = 11, colour = "black"),
         axis.title= element_text(face = "bold", size = 14, colour = "black"),
         panel.background = element_blank(),
         panel.border = element_rect(fill = NA, colour = "black"),
         legend.position = "top",
         legend.text = element_text(size = 10, face = "bold"),
         legend.title = element_text(size = 11, face = "bold")) +
  scale_fill_continuous(low = "orange3", high = "#FF732324")+
  annotate('text', label = Mantel_r1, x = 5000, y = 0.66, size = 5, colour = 'black')+
  annotate('text', label = P1, x = 5000, y = 0.6, size =5, colour = 'black') +
  ylim(0, 0.7)
gg

#################################Beta diversity decomposition####################################
library(adespatial)
#install.packages("adespatial")
library(data.table)
library(tidyr)
library(stringr)
library(ggtern)
#install.packages("ggtern")
library(vcd)
#install.packages("vcd")
library(betapart) # Load betapart package
#install.packages("betapart")
library(reshape2) # Load reshape2 package
library(ggtern) # Load ggtern package
#install.packages("ggtern")
# 2. Load OTU matrix ####
sps <- read.table('OTU.txt', sep="\t", header=T, row.names=1)
otu_s
otu_s_L <- otu_s[, grepl("ND", colnames(otu_s))]
otu_s_L<-otu_s_L[rowSums(otu_s_L > 10) >= 2, ]
# Extract columns whose names contain PM
otu_s_E <- otu_s[, grepl("PF", colnames(otu_s))]
otu_s_E<-otu_s_E[rowSums(otu_s_E > 10) >= 2, ]
otu_w
otu_w_L <- otu_w[, grepl("NW", colnames(otu_w))]
otu_w_L<-otu_w_L[rowSums(otu_w_L > 10) >= 2, ]
# Extract columns whose names contain PM
otu_w_E <- otu_w[, grepl("PM", colnames(otu_w))]
otu_w_E<-otu_w_E[rowSums(otu_w_E > 10) >= 2, ]
# Order: Post-overwintering S, Pre-overwintering S, Post-overwintering W, Pre-overwintering W
sps=t(otu_w_E)

# 3. Beta diversity decomposition ####
btres <- beta.div.comp(sps, coef = 'J', quant = F,save.abc = TRUE)

# View beta diversity decomposition
btres$part
b <- as.data.frame(t(btres$part))
str(btres)
write.table(b, 'otu_w_E_diversity_decomposition.txt', sep = '\t', col.names = NA, quote = FALSE)

# 4. Extract matrix ####
Repl <- as.data.frame(as.matrix(btres$repl))
diag(Repl) <- 0 # Community similarity matrix diagonal values are self-similarities, set to 0 for later removal
Repl[upper.tri(Repl)] <- 0 # Community similarity matrix is symmetric, so only select the lower triangle values; set upper triangle to 0 for later removal
Repl$st <- row.names(Repl)
Repl <- reshape2::melt(Repl,id.vars="st") # Convert data frame from wide format to long format
Repl <- subset(Repl, value != 0) # Keep only non-zero values, i.e., remove diagonal and upper triangle
colnames(Repl)=c("Var1","Var2","Repl") # Rename columns

RichDiff <- as.data.frame(as.matrix(btres$rich))
diag(RichDiff) <- 0
RichDiff[upper.tri(RichDiff)] <- 0
RichDiff$st <- row.names(RichDiff)
RichDiff <- reshape2::melt(RichDiff,id.vars="st")
RichDiff <- subset(RichDiff, value != 0)
colnames(RichDiff)=c("Var1","Var2","RichDiff") # Rename columns

Similarity <- 1-as.data.frame(as.matrix(btres$D))
diag(Similarity) <- 0
Similarity[upper.tri(Similarity)] <- 0
Similarity$st <- row.names(Similarity)
Similarity <- reshape2::melt(Similarity,id.vars="st")
Similarity <- subset(Similarity, value != 0)
colnames(Similarity)=c("Var1","Var2","Similarity") # Rename columns

### Combine results
dff=merge(Repl,RichDiff,by=c("Var1","Var2"))
dff=merge(dff,Similarity,by=c("Var1","Var2"))
colnames(dff)=c("site1","site2","Repl","RichDiff","Similarity") # Rename columns
dff$site=paste(dff$site1,dff$site2,sep="_") # Concatenate site1 and site2 columns


# 5. Ternary plot visualization ####
dff$Repl=as.numeric(dff$Repl)
dff$RichDiff=as.numeric(dff$RichDiff)
dff$Similarity=as.numeric(dff$Similarity)

# Calculate mean
dm=as.data.frame(t(data.frame(mean=colMeans(dff[,3:5]))))
dm

p=ggtern(data=dff,aes(Similarity,Repl,RichDiff))+
  geom_point(alpha=0.2,size=3,col='#63bfb8')+
  scale_fill_gradient(low = "blue",
                      high = "red")+
  labs(x ="Similarity",y = "Repl",z = "RichDiff", # jac etc. changed to subscript in exported PDF
       title = "",fill = "level")+
  guides(alpha = "none",position="bottom")+
  theme_rgbw()+
  theme(legend.position = "bottom",
        legend.key = element_rect(fill = NA),
        text=element_text(size=16,  family="serif"))
p

ggsave("otu_w_E_ternary_plot.pdf",plot= p, dpi=1200,width=10.08,height=10.94)
######################################MST####################################
library(NST)
## 4. Calculate MST (Modified Stochasticity Ratio)
############################

# W-L, W-E, S-L, S-E
# Transpose OTU table
otu_df_t <- as.data.frame(t(otu_w_L))  # Rows = sample names
otu_df_t <- as.data.frame(t(otu_w_E))  # Rows = sample names
otu_df_t <- as.data.frame(t(otu_s_L))  # Rows = sample names
otu_df_t <- as.data.frame(t(otu_s_E))  # Rows = sample names
# Create group data.frame with row names exactly matching sample names
group <- data.frame(Group = rep("All", nrow(otu_df_t)))
rownames(group) <- rownames(otu_df_t)  # Critical! Row names must match OTU table

# Calculate MST
set.seed(123)
mst_result <- tNST(
  comm = otu_df_t,
  group = group,
  dist.method = "bray",
  abundance.weighted = TRUE,
  rand = 1000,
  nworker = 2
)
save(mst_result, file = "otu_w_Emst_result.RData")
# 1. Define samples to exclude
del_samp <- c("NW1-1","NW1-2","NW1-3","NW2-1","NW2-2","NW2-3")
# 2. Filter: keep rows where name2 is not in the exclude list
pair_filter <- subset(mst_result$index.pair, !(name2 %in% del_samp))
# 3. Calculate the mean of two columns
mean_ST <- mean(pair_filter$ST.ij.bray)
mean_MST <- mean(pair_filter$MST.ij.bray)

# Output results
cat("ST.ij.bray mean:", mean_ST, "\n")
cat("MST.ij.bray mean:", mean_MST, "\n")
############################
## 5. Extract MST results
############################

mst_value <- mst_result$index.grp

print(mst_value)

write.csv(mst_value,
          "otu_w_LMST_Result.csv",
          row.names = FALSE)

############################
## 6. Simple interpretation of output
############################

if (mst_value > 0.5) {
  cat("Stochastic process dominates (MST > 50%)\n")
} else {
  cat("Deterministic process dominates (MST < 50%)\n")
}
###############################################################
otu_df_t <- as.data.frame(t(otu_w_E))  # Rows = sample names
group <- data.frame(Group = rep("All", nrow(otu_df_t)))
rownames(group) <- rownames(otu_df_t)  # Critical! Row names must match OTU table

# Calculate MST
set.seed(123)
mst_result <- tNST(
  comm = otu_df_t,
  group = group,
  dist.method = "bray",
  abundance.weighted = TRUE,
  rand = 1000
)

############################
## 5. Extract MST results
############################

mst_value <- mst_result$index.grp

print(mst_value)

write.csv(mst_value,
          "otu_w_EMST_Result.csv",
          row.names = FALSE)

############################
## 6. Simple interpretation of output
############################

if (mst_value > 0.5) {
  cat("Stochastic process dominates (MST > 50%)\n")
} else {
  cat("Deterministic process dominates (MST < 50%)\n")
}
###############################################################
otu_df_t <- as.data.frame(t(otu_s_L))  # Rows = sample names
group <- data.frame(Group = rep("All", nrow(otu_df_t)))
rownames(group) <- rownames(otu_df_t)  # Critical! Row names must match OTU table

# Calculate MST
set.seed(123)
mst_result <- tNST(
  comm = otu_df_t,
  group = group,
  dist.method = "bray",
  abundance.weighted = TRUE,
  rand = 1000
)

############################
## 5. Extract MST results
############################

mst_value <- mst_result$index.grp

print(mst_value)

write.csv(mst_value,
          "otu_s_LMST_Result.csv",
          row.names = FALSE)

############################
## 6. Simple interpretation of output
############################

if (mst_value > 0.5) {
  cat("Stochastic process dominates (MST > 50%)\n")
} else {
  cat("Deterministic process dominates (MST < 50%)\n")
}
###############################################################
otu_df_t <- as.data.frame(t(otu_s_E))  # Rows = sample names
group <- data.frame(Group = rep("All", nrow(otu_df_t)))
rownames(group) <- rownames(otu_df_t)  # Critical! Row names must match OTU table

# Calculate MST
set.seed(123)
mst_result <- tNST(
  comm = otu_df_t,
  group = group,
  dist.method = "bray",
  abundance.weighted = TRUE,
  rand = 1000
)

############################
## 5. Extract MST results
############################

mst_value <- mst_result$index.grp

print(mst_value)

write.csv(mst_value,
          "otu_s_EMST_Result.csv",
          row.names = FALSE)

############################
## 6. Simple interpretation of output
############################

if (mst_value > 0.5) {
  cat("Stochastic process dominates (MST > 50%)\n")
} else {
  cat("Deterministic process dominates (MST < 50%)\n")
}
